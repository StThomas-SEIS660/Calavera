For more information about running Artifactory inside IBM WebSphere please visit:

http://www.jfrog.com/confluence/display/RTF/Deploying+on+Servlet+Containers#DeployingonServletContainers-RunningArtifactoryonIBMWebSphere